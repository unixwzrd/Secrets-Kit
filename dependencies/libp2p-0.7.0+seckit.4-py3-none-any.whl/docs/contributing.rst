Contributing
------------

Thank you for your interest in contributing! We welcome all contributions no matter
their size. Please read along to learn how to get started. If you get stuck, feel free
to ask for help in `Libp2p Discover Server <https://discord.gg/GK8TxRNh2s>`_.

Setting the stage
~~~~~~~~~~~~~~~~~

To get started, fork the repository to your own GitHub account, then clone it
to your development machine:

.. code:: sh

    git clone git@github.com:your-github-username/py-libp2p.git

Next, install the development dependencies and set up the project. We recommend using a
virtual environment, such as `virtualenv <https://virtualenv.pypa.io/en/stable/>`_ or
Python's built-in ``venv`` module. Instructions vary by platform:

.. note::

    py-libp2p contributor setup is currently supported on Python versions ``<= 3.13``.

Linux Setup
^^^^^^^^^^^

Prerequisites
"""""""""""""

On Debian Linux, you need to install the following dependencies:

- `GNU Multiprecision Arithmetic Library <https://gmplib.org/>`_
- `CMake <https://cmake.org>`_
- `freedesktop.org pkg-config <https://www.freedesktop.org/wiki/Software/pkg-config>`_

Install them with:

.. code:: sh

    sudo apt-get install cmake pkg-config libgmp-dev

Setup Steps
"""""""""""

Install the development dependencies using a virtual environment:

**Option 1: Using the setup script (recommended):**

.. code:: sh

    cd py-libp2p
    ./scripts/setup_dev.sh

.. note::

    On Linux, if you are not already in a virtual environment, the script will create one
    automatically and instruct you to activate it.

**Option 2: Using uv (recommended, same as CI):**

First, install ``uv`` if you haven't already:

.. code:: sh

    curl -LsSf https://astral.sh/uv/install.sh | sh

Or using pip:

.. code:: sh

    pip install uv

Then set up the development environment:

.. code:: sh

    cd py-libp2p
    uv sync --group dev
    uv run pre-commit install

**Option 3: Manual setup with pip:**

.. code:: sh

    cd py-libp2p
    python3 -m venv .venv
    . .venv/bin/activate
    pip install --upgrade pip  # Ensure pip >= 25.1 for PEP 735 support
    pip install --group dev -e .
    pre-commit install

**Note:** This project uses PEP 735 ``[dependency-groups]`` which requires pip >= 25.1.
If you have an older pip version, upgrade it first.

An alternative using ``virtualenv``:

.. code:: sh

    cd py-libp2p
    virtualenv -p python .venv
    . .venv/bin/activate
    pip install --upgrade pip  # Ensure pip >= 25.1 for PEP 735 support
    pip install --group dev -e .
    pre-commit install

macOS Setup
^^^^^^^^^^^

Prerequisites
"""""""""""""

On macOS, you need to install the following dependencies:

- `GNU Multiprecision Arithmetic Library <https://gmplib.org/>`_
- `CMake <https://cmake.org>`_
- `freedesktop.org pkg-config <https://www.freedesktop.org/wiki/Software/pkg-config>`_

Install them with:

.. code:: sh

    brew install cmake pkgconfig gmp

Setup Steps
"""""""""""

Install the development dependencies using a virtual environment:

**Option 1: Using the setup script (recommended):**

.. code:: sh

    cd py-libp2p
    ./scripts/setup_dev.sh

**Option 2: Using uv (recommended, same as CI):**

First, install ``uv`` if you haven't already:

.. code:: sh

    curl -LsSf https://astral.sh/uv/install.sh | sh

Or using Homebrew:

.. code:: sh

    brew install uv

Or using pip:

.. code:: sh

    pip install uv

Then set up the development environment:

.. code:: sh

    cd py-libp2p
    CFLAGS="$(pkg-config --cflags gmp)" LDFLAGS="$(pkg-config --libs gmp)" uv sync --group dev
    uv run pre-commit install

**Option 3: Manual setup with pip:**

.. code:: sh

    cd py-libp2p
    python3 -m venv .venv
    . .venv/bin/activate
    pip install --upgrade pip  # Ensure pip >= 25.1 for PEP 735 support
    CFLAGS="$(pkg-config --cflags gmp)" LDFLAGS="$(pkg-config --libs gmp)" pip install --group dev -e .
    pre-commit install

**Note:** This project uses PEP 735 ``[dependency-groups]`` which requires pip >= 25.1.
If you have an older pip version, upgrade it first.

An alternative using ``virtualenv``:

.. code:: sh

    cd py-libp2p
    virtualenv -p python .venv
    . .venv/bin/activate
    pip install --upgrade pip  # Ensure pip >= 25.1 for PEP 735 support
    pip install --group dev -e .
    pre-commit install

Windows Development Setup
^^^^^^^^^^^^^^^^^^^^^^^^^

Prerequisites
"""""""""""""

1. **Python 3.11+**
   - Download and install Python from `python.org <https://www.python.org/downloads/>`_ or the Microsoft Store.
   - Verify installation:

   .. code:: powershell

        python --version

2. **Git**
   - Install Git using Windows Package Manager (``winget``) or download from `git-scm.com <https://git-scm.com/download/win>`_.
   - Verify:

   .. code:: powershell

        winget install --id Git.Git -e
        git --version

3. **CMake**
   - Install CMake with ``winget`` or download from `cmake.org <https://cmake.org/download/>`_.
   - Add CMake to your PATH during installation, then verify:

   .. code:: powershell

        winget install --id Kitware.CMake -e
        cmake --version

4. **Make**
    - Option 1: Use Git Bash (included with Git) as a shell.
    - Option 2: Install ``make`` via Chocolatey (install Chocolatey first if needed: `choco.io <https://chocolatey.org/install>`_).
    - Verify installation:

   .. code:: powershell

        choco install make
        make --version


Setup Steps
"""""""""""

1. **Clone the Repository**
   - Open PowerShell or Git Bash and run:

   .. code:: powershell

        git clone git@github.com:your-github-username/py-libp2p.git
        cd py-libp2p

2. **Create a Virtual Environment**
   - In PowerShell:

   .. code:: powershell

        python -m venv venv
        .\venv\Scripts\activate

3. **Install Dependencies**

   **Option A: Using uv (recommended, same as CI):**

   First, install ``uv`` if you haven't already:

   .. code:: powershell

        # Using pip
        pip install uv

        # Or using winget
        winget install --id=astral-sh.uv

   Then set up the development environment:

   .. code:: powershell

        uv sync --group dev
        uv run pre-commit install

   **Option B: Using pip:**

   .. code:: powershell

        pip install --upgrade pip  # Ensure pip >= 25.1 for PEP 735 support
        pip install --group dev -e .
        pre-commit install

   **Note:** This project uses PEP 735 ``[dependency-groups]`` which requires pip >= 25.1.
   If you have an older pip version, upgrade it first.

4. **Verify Setup**
   - Run the tests to ensure everything works:

   .. code:: powershell

        pytest -v

   - If using ``make test`` with Git Bash:

   .. code:: bash

        make test

Notes
"""""

- Use PowerShell, Command Prompt, or Git Bash as your shell.
- Ensure all tools (Python, Git, CMake) are in your system PATH.

Requirements
^^^^^^^^^^^^

The protobuf description in this repository was generated by ``protoc`` at version
``30.1``.

Running the tests
~~~~~~~~~~~~~~~~~

A great way to explore the code base is to run the tests.

We can run all tests with:

.. code:: sh

    make test


Code Style
~~~~~~~~~~

We use `pre-commit <https://pre-commit.com/>`_ to enforce a consistent code style across
the library. This tool runs automatically with every commit, but you can also run it
manually with:

.. code:: sh

    make lint

If you need to make a commit that skips the ``pre-commit`` checks, you can do so with
``git commit --no-verify``.

This library uses type hints, which are enforced by the ``mypy`` tool (part of the
``pre-commit`` checks). All new code is required to land with type hints, with the
exception of code within the ``tests`` directory.

Path handling
^^^^^^^^^^^^^

Use the cross-platform path utilities in ``libp2p.utils.paths`` instead of ``os.path``
or hard-coded separators. Prefer ``join_paths()`` over ``os.path.join()``,
``get_script_dir(__file__)`` over ``os.path.dirname(__file__)``, and ``create_temp_file()``
or ``get_temp_dir()`` over hard-coded ``/tmp/`` or ``C:\\``. This keeps the codebase
working on Windows, macOS, and Linux. Run ``python scripts/audit_paths.py`` to check
for path issues; the same audit runs in ``pre-commit`` and fails on P0/P1 issues.

For the full API reference, see :mod:`libp2p.utils.paths`. A working example is
available in :doc:`examples.path_handling`.

Documentation
~~~~~~~~~~~~~

Good documentation will lead to quicker adoption and happier users. Please check out our
guide on
`how to create documentation for the Python Ethereum ecosystem <https://github.com/ethereum/snake-charmers-tactical-manual/blob/main/documentation.md>`_.

Adding Examples
~~~~~~~~~~~~~~~

To add a new example (e.g., identify):

1. Create a directory in ``examples/identify``
2. Create a file ``examples/identify/identify.py`` with the example code
3. Add ``__init__.py`` to make it a proper Python package (automatically discovered by find_packages() in ``setup.py``)
4. Add the example in the example list ``docs/examples.rst``
5. Add example tests in ``tests/core/examples/test_examples.py``
6. Add the example documentation in ``docs/examples.identify.rst``
7. Add a news fragment for the new release in file ``newsfragments/536.feature.rst`` (fix-id.type.rst)
8. Generate doc files with ``make docs`` or ``make linux-docs`` in linux (generates files ``libp2p.identity.identify.rst libp2p.identity.rst libp2p.identity.identify.pb.rst``)
9. Add the example to ``setup.py``:

   .. code:: python

       entry_points={
           "console_scripts": [
               "chat-demo=examples.chat.chat:main",
               "echo-demo=examples.echo.echo:main",
               "ping-demo=examples.ping.ping:main",
               "identify-demo=examples.identify.identify:main",
               "circuit-relay-demo=examples.circuit_relay.relay_example:main"
           ],
       }

10. Run ``make package-test`` to test the release:

    .. code:: sh

        .....
        Activate with ``source <temp-dir>/package-smoke-test/bin/activate``
        (The exact path is shown by the script; use that path.)
        Press enter when the test has completed. The directory will be deleted.

    Then test the example:

    .. code:: sh

        source <temp-dir>/package-smoke-test/bin/activate
        (package-smoke-test) $ identify-demo

Pull Requests
~~~~~~~~~~~~~

It's a good idea to make pull requests early on. A pull request represents the start of
a discussion, and doesn't necessarily need to be the final, finished submission.

GitHub's documentation for working on pull requests is
`available here <https://docs.github.com/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests>`_.

Once you've made a pull request, take a look at the Circle CI build status in the
GitHub interface and make sure all tests are passing. In general pull requests that
do not pass the CI build yet won't get reviewed unless explicitly requested.

If the pull request introduces changes that should be reflected in the release notes,
please add a newsfragment file as explained
`here <https://github.com/libp2p/py-libp2p/tree/main/newsfragments>`_.

If possible, the change to the release notes file should be included in the commit that
introduces the feature or bugfix.

Releasing
~~~~~~~~~

Releases are typically done from the ``main`` branch, except when releasing a beta (in
which case the beta is released from ``main``, and the previous stable branch is
released from said branch).

Final test before each release
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Before releasing a new version, build and test the package that will be released:

.. code:: sh

    git checkout main && git pull
    make package-test

This will build the package and install it in a temporary virtual environment. Follow
the instructions to activate the venv and test whatever you think is important.

You can also preview the release notes:

.. code:: sh

    towncrier --draft

Build the release notes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Before bumping the version number, build the release notes. You must include the part of
the version to bump (see below), which changes how the version number will show in the
release notes.

.. code:: sh

    make notes bump=$$VERSION_PART_TO_BUMP$$

If there are any errors, be sure to re-run make notes until it works.

Push the release to github & pypi
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

After confirming that the release package looks okay, release a new version:

.. code:: sh

    make release bump=$$VERSION_PART_TO_BUMP$$

This command will:

- Bump the version number as specified in ``.pyproject.toml`` and ``setup.py``.
- Create a git commit and tag for the new version.
- Build the package.
- Push the commit and tag to github.
- Push the new package files to pypi.

Which version part to bump
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

``$$VERSION_PART_TO_BUMP$$`` must be one of: ``major``, ``minor``, ``patch``, ``stage``,
or ``devnum``.

The version format for this repo is ``{major}.{minor}.{patch}`` for stable, and
``{major}.{minor}.{patch}-{stage}.{devnum}`` for unstable (``stage`` can be alpha or
beta).

If you are in a beta version, ``make release bump=stage`` will switch to a stable.

To issue an unstable version when the current version is stable, specify the new version
explicitly, like ``make release bump="--new-version 4.0.0-alpha.1"``

You can see what the result of bumping any particular version part would be with
``bump-my-version show-bump``
