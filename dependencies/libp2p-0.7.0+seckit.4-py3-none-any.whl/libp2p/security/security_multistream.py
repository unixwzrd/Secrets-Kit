from abc import (
    ABC,
)
from collections import (
    OrderedDict,
)
import logging

from libp2p.abc import (
    IRawConnection,
    ISecureConn,
    ISecureTransport,
)
from libp2p.custom_types import (
    TProtocol,
    TSecurityOptions,
)
from libp2p.peer.id import (
    ID,
)
from libp2p.protocol_muxer.exceptions import (
    MultiselectClientError,
    MultiselectError,
)
from libp2p.protocol_muxer.generic_selector import (
    GenericMultistreamSelector,
)
from libp2p.protocol_muxer.multiselect import (
    Multiselect,
)
from libp2p.protocol_muxer.multiselect_client import (
    MultiselectClient,
)

logger = logging.getLogger(__name__)

"""
Represents a secured connection object, which includes a connection and details about
the security involved in the secured connection

Relevant go repo: https://github.com/libp2p/go-conn-security/blob/master/interface.go
"""


class SecurityMultistream(ABC):
    """
    SSMuxer is a multistream stream security transport multiplexer.

    Go implementation: github.com/libp2p/go-conn-security-multistream/ssms.go
    """

    _selector: "GenericMultistreamSelector[ISecureTransport]"

    def __init__(self, secure_transports_by_protocol: TSecurityOptions) -> None:
        self._selector = GenericMultistreamSelector()

        for protocol, transport in secure_transports_by_protocol.items():
            self.add_transport(protocol, transport)

    @property
    def transports(self) -> "OrderedDict[TProtocol, ISecureTransport]":
        return self._selector.handlers

    @property
    def multiselect(self) -> Multiselect:
        return self._selector.multiselect

    @property
    def multiselect_client(self) -> MultiselectClient:
        return self._selector.multiselect_client

    def add_transport(self, protocol: TProtocol, transport: ISecureTransport) -> None:
        """
        Add a protocol and its corresponding transport to multistream-
        select(multiselect). The order that a protocol is added is exactly the
        precedence it is negotiated in multiselect.

        :param protocol: the protocol name, which is negotiated in multiselect.
        :param transport: the corresponding transportation to the ``protocol``.
        """
        self._selector.add_handler(protocol, transport)

    async def secure_inbound(self, conn: IRawConnection) -> ISecureConn:
        """
        Secure the connection, either locally or by communicating with opposing
        node via conn, for an inbound connection (i.e. we are not the
        initiator)

        :return: secure connection object (that implements secure_conn_interface)
        """
        logger.debug("SecurityMultistream.secure_inbound: selecting transport")
        transport = await self.select_transport(conn, False)
        logger.debug("SecurityMultistream: transport selected, securing")
        secure_conn = await transport.secure_inbound(conn)
        logger.debug("SecurityMultistream: secure connection established")
        return secure_conn

    async def secure_outbound(self, conn: IRawConnection, peer_id: ID) -> ISecureConn:
        """
        Secure the connection, either locally or by communicating with opposing
        node via conn, for an inbound connection (i.e. we are the initiator)

        :return: secure connection object (that implements secure_conn_interface)
        """
        transport = await self.select_transport(conn, True)
        secure_conn = await transport.secure_outbound(conn, peer_id)
        return secure_conn

    async def select_transport(
        self, conn: IRawConnection, is_initiator: bool
    ) -> ISecureTransport:
        """
        Select a transport that both us and the node on the other end of conn
        support and agree on.

        :param conn: conn to choose a transport over
        :param is_initiator: true if we are the initiator, false otherwise
        :return: selected secure transport
        """
        try:
            _, transport = await self._selector.select(conn, is_initiator)
        except (MultiselectError, MultiselectClientError) as error:
            raise MultiselectError(
                "Failed to negotiate a security protocol: no protocol selected"
            ) from error
        return transport
