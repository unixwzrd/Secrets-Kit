from __future__ import annotations

from collections.abc import (
    Sequence,
)

import multiaddr

from libp2p.abc import (
    INetworkService,
    IPeerRouting,
)
from libp2p.host.basic_host import (
    BasicHost,
)
from libp2p.host.exceptions import (
    ConnectionFailure,
)
from libp2p.peer.peerinfo import (
    PeerInfo,
)
from libp2p.rcmgr import ResourceManager


# RoutedHost is a p2p Host that includes a routing system.
# This allows the Host to find the addresses for peers when it does not have them.
class RoutedHost(BasicHost):
    """
    RoutedHost is a p2p Host that includes a routing system.

    This allows the Host to find the addresses for peers when it does not have them.
    """

    _router: IPeerRouting

    def __init__(
        self,
        network: INetworkService,
        router: IPeerRouting,
        enable_mDNS: bool = False,
        enable_upnp: bool = False,
        enable_autotls: bool = False,
        bootstrap: list[str] | None = None,
        resource_manager: ResourceManager | None = None,
        *,
        bootstrap_allow_ipv6: bool = False,
        bootstrap_dns_timeout: float = 10.0,
        bootstrap_dns_max_retries: int = 3,
        announce_addrs: Sequence[multiaddr.Multiaddr] | None = None,
    ):
        """
        Initialize a RoutedHost instance.

        :param network: Network service implementation
        :param router: Peer routing implementation
        :param enable_mDNS: Enable mDNS discovery
        :param enable_upnp: Enable UPnP port mapping
        :param enable_autotls: Enable AutoTLS certificate provisioning.
        :param bootstrap: Bootstrap peer addresses
        :param resource_manager: Optional resource manager instance
        :type resource_manager: :class:`libp2p.rcmgr.ResourceManager` or None
        :param bootstrap_allow_ipv6: If True, bootstrap uses IPv6+TCP when available.
        :param bootstrap_dns_timeout: DNS resolution timeout in seconds per attempt.
        :param bootstrap_dns_max_retries: Max DNS resolution retries (with backoff).
        :param announce_addrs: If set, replace listen addrs in get_addrs()
        """
        super().__init__(
            network,
            enable_mDNS,
            enable_upnp,
            enable_autotls,
            bootstrap,
            resource_manager=resource_manager,
            bootstrap_allow_ipv6=bootstrap_allow_ipv6,
            bootstrap_dns_timeout=bootstrap_dns_timeout,
            bootstrap_dns_max_retries=bootstrap_dns_max_retries,
            announce_addrs=announce_addrs,
        )
        self._router = router

    async def connect(self, peer_info: PeerInfo) -> None:
        """
        Ensure there is a connection between this host and the peer
        with given `peer_info.peer_id`. See (basic_host).connect for more
        information.

        RoutedHost's Connect differs in that if the host has no addresses for a
        given peer, it will use its routing system to try to find some.

        :param peer_info: peer_info of the peer we want to connect to
        :type peer_info: peer.peerinfo.PeerInfo
        """
        # check if we were given some addresses, otherwise, find some with the
        # routing system.
        if not peer_info.addrs:
            found_peer_info = await self._router.find_peer(peer_info.peer_id)
            if not found_peer_info:
                raise ConnectionFailure("Unable to find Peer address")
            self.peerstore.add_addrs(peer_info.peer_id, found_peer_info.addrs, 120)
        self.peerstore.add_addrs(peer_info.peer_id, peer_info.addrs, 120)

        # there is already a connection to this peer
        if peer_info.peer_id in self._network.connections:
            return

        await self._network.dial_peer(peer_info.peer_id)
